from flask import Flask
from flask_restful import Api, Resource, reqparse, abort, fields, marshal_with
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from models import *
from serializers import *

app = Flask(__name__)
api = Api(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:0000@localhost/PPLab'
db = SQLAlchemy(app)


class Notebook(Resource):
	@marshal_with(note_resource_fields)
	def get(self):
		result = NoteModel.query.all()

		return result, 200

	@marshal_with(note_resource_fields)
	def post(self):
		args = note_post_args.parse_args()

		owner_exists = UserModel.query.filter_by(id=args['owner']).first()
		if not owner_exists:
			abort(404, message="Could not find owner with that id")

		for editor in args['editors']:
			editor_exists = UserModel.query.filter_by(id=editor).first()
			if not editor_exists:
				abort(404, message="Could not find editor with that id")

		note = NoteModel(name=args['name'], text=args['text'], owner=args['owner'], editors=args['editors'])
		db.session.add(note)
		db.session.commit()
		return note, 201


class Users(Resource):
	@marshal_with(user_resource_fields)
	def get(self):
		result = UserModel.query.all()

		return result, 200

	@marshal_with(user_resource_fields)
	def post(self):
		args = user_post_args.parse_args()

		user = UserModel(username=args['username'], password=generate_password_hash(args['password']))
		db.session.add(user)
		db.session.commit()
		return user, 201


class Note(Resource):
	@marshal_with(note_resource_fields)
	def get(self, note_id):
		result = NoteModel.query.filter_by(id=note_id).first()
		if not result:
			abort(404, message="Could not find note with that id")
		return result, 200

	@marshal_with(note_resource_fields)
	def put(self, note_id):
		args = note_put_args.parse_args()
		result = NoteModel.query.filter_by(id=note_id).first()
		if not result:
			abort(404, message="Note doesn't exist, cannot update")

		if args['name']:
			result.name = args['name']
		if args['text']:
			result.text = args['text']
		if args['owner']:
			owner_exists = UserModel.query.filter_by(id=args['owner']).first()
			if not owner_exists:
				abort(404, message="Could not find user with that id")
			result.owner = args['owner']
		if args['editors']:
			for editor in args['editors']:
				editor_exists = UserModel.query.filter_by(id=editor).first()
				if not editor_exists:
					abort(404, message="Could not find editor with that id")
			result.editors = args['editors']

		db.session.add(result)
		db.session.commit()

		return result, 200

	def delete(self, note_id):
		result = NoteModel.query.filter_by(id=note_id).first()
		if not result:
			abort(404, message="Can not delete nonexistent note")
		db.session.delete(result)
		db.session.commit()
		return 204


class User(Resource):
	@marshal_with(user_resource_fields)
	def get(self, user_id):
		result = UserModel.query.filter_by(id=user_id).first()
		if not result:
			abort(404, message="Could not find user with that id")
		return result, 200

	@marshal_with(user_resource_fields)
	def put(self, user_id):
		args = user_put_args.parse_args()
		result = UserModel.query.filter_by(id=user_id).first()
		if not result:
			abort(404, message="User doesn't exist, cannot update")

		if args['username']:
			result.username = args['username']
		if args['password']:
			result.password = generate_password_hash(args['password'])

		db.session.commit()

		return result, 200

	def delete(self, user_id):
		result = UserModel.query.filter_by(id=user_id).first()
		if not result:
			abort(404, message="Can not delete nonexistent user")
		db.session.delete(result)
		db.session.commit()
		return 204

api.add_resource(Notebook, "/notebook")
api.add_resource(Users, "/users")
api.add_resource(Note, "/note/<int:note_id>")
api.add_resource(User, "/user/<int:user_id>")

if __name__ == "__main__":
	app.run(debug=True)