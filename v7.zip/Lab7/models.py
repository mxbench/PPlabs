from api import *


class UserModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), nullable=False)
    password = db.Column(db.String(200), nullable=False)


class NoteModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), nullable=False)
    text = db.Column(db.String(404), nullable=False)
    owner = db.Column(db.Integer, nullable=False)
    editors = db.Column(db.PickleType, nullable=False)
