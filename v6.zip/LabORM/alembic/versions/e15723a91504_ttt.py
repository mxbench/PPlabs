"""ttt

Revision ID: e15723a91504
Revises: 
Create Date: 2020-12-09 15:42:57.022935

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'e15723a91504'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
