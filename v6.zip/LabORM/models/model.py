from sqlalchemy import Column, String, Integer, ForeignKey, orm, create_engine
from sqlalchemy.ext.declarative import declarative_base

# engine= create_engine(BD_URI)

Base = declarative_base()

# server_default=text("CURRENT_TIMESTAMP"))

class User(Base):
    __tablename__ = 'user'

    id = Column(Integer, primary_key=True)
    login = Column(String)
    email = Column(String)
    password = Column(String)
    name = Column(String)


class Note(Base):
    __tablename__ = 'note'

    id = Column(Integer, primary_key=True)
    owner_id = Column(Integer, ForeignKey(User.id))
    owner = orm.relationship(User, backref="Note", lazy="joined")


