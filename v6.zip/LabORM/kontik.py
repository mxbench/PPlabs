from models.model import *

user1 = User(id=13, login='Alex', email='Alcatras@gmail.com', password='qwerty1234', name='Alexander')
note1 = Note(id=13,  photoUrls='https://sdfdsdf.image.net', owner=user1)