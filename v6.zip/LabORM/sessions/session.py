from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models.model import *

engine = create_engine('postgresql://postgres:0000@localhost:5432/LabORM')
Session = sessionmaker(bind=engine)
session = Session()

user1 = User(id=13, login='Alex', email='Alcatras@gmail.com', password='qwerty1234', name='Alexander')
note1 = Note(id=13, owner=user1)
user3 = User(id=23, login='Alex', email='Alcatras@gmail.com', password='qwerty1234', name='Alexander')


note3 = Note(id=44, owner=user3)
user2 = User(id=28, login='Max', email='m@gmail.com', password='rere', name='tewr')
note2 = Note(id=28, owner=user3)

session.add(user1)
session.add(note1)
session.add(user3)


session.add(user2)
session.add(note2)
session.add(note3)
session.commit()
