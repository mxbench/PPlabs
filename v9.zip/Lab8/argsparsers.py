from flask_restful import reqparse


note_post_args = reqparse.RequestParser()
note_post_args.add_argument("name", type=str, help="Name is required", required=True)
note_post_args.add_argument("text", type=str, help="Text is required", required=True)
note_post_args.add_argument("editors", type=list, location='json')

note_put_args = reqparse.RequestParser()
note_put_args.add_argument("name", type=str, help="Name is required")
note_put_args.add_argument("text", type=str, help="Text is required")
note_put_args.add_argument("editors", type=list, location='json')

user_post_args = reqparse.RequestParser()
user_post_args.add_argument("username", type=str, help="Username is required", required=True)
user_post_args.add_argument("password", type=str, help="Password is required", required=True)

user_put_args = reqparse.RequestParser()
user_put_args.add_argument("username", type=str, help="Username is required")
user_put_args.add_argument("password", type=str, help="Password is required")
