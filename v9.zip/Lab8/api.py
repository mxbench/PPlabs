from flask import Flask
from flask_restful import Api, Resource, abort, marshal_with
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from serializers import *
from argsparsers import *
from flask_jwt_extended import JWTManager, jwt_required, get_jwt_identity, create_access_token
from datetime import timedelta

app = Flask(__name__)
api = Api(app)
db = SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:0000@localhost/APItest'
app.config['SECRET_KEY'] = 'a76351ff35f54d768867f9e16a74e712'
jwt = JWTManager(app)





class UserModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(30), nullable=False)
    password = db.Column(db.String(200), nullable=False)

    def get_token(self, expire_time=24):
        token = create_access_token(identity=self.id, expires_delta=timedelta(expire_time))
        return token


class NoteModel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(30), nullable=False)
    text = db.Column(db.String(404), nullable=False)
    owner = db.Column(db.Integer, nullable=False)
    editors = db.Column(db.PickleType, nullable=True)


class Notebook(Resource):
    @jwt_required
    @marshal_with(note_resource_fields)
    def get(self):
        owner = get_jwt_identity()
        notes = NoteModel.query.filter_by(owner=owner).all()

        return notes, 200

    @jwt_required
    @marshal_with(note_resource_fields)
    def post(self):
        args = note_post_args.parse_args()
        owner = get_jwt_identity()
        owner_exists = UserModel.query.filter_by(id=owner).first()
        if not owner_exists:
            abort(404, message="Could not find owner with that token")

        if args['editors']:
            for editor in args['editors']:
                editor_exists = UserModel.query.filter_by(id=editor).first()
                if not editor_exists:
                    abort(404, message="Could not find editor with that id")
            if len(args['editors']) > 5:
                abort(403, message="More than 5 editors is not allowed")
        else:
            args['editors'] = []

        editors = args['editors']
        if owner not in editors:
            editors.append(owner)

        if len(args['text']) > 404:
            abort(403, message="Text longer than 404 characters is not allowed")

        note = NoteModel(name=args['name'], text=args['text'], owner=owner, editors=editors)
        db.session.add(note)
        db.session.commit()
        return note, 201


class Users(Resource):
    def get(self):
        args = user_post_args.parse_args()
        user = UserModel.query.filter_by(username=args['username']).first()
        if not user or not check_password_hash(user.password, args['password']):
            abort(404, message='Invalid username or password')
        token = user.get_token()

        return {'access_token': token}, 200

    def post(self):
        args = user_post_args.parse_args()

        user = UserModel(username=args['username'], password=generate_password_hash(args['password']))
        db.session.add(user)
        db.session.commit()
        token = user.get_token()

        return {'access_token': token}, 201


class Note(Resource):
    @jwt_required
    @marshal_with(note_resource_fields)
    def get(self, note_id):
        result = NoteModel.query.filter_by(id=note_id).first()
        if not result:
            abort(404, message="Could not find note with that id")

        user = get_jwt_identity()
        if user not in result.editors:
            abort(403, message="You're not allowed to view this note")

        return result, 200

    @jwt_required
    @marshal_with(note_resource_fields)
    def put(self, note_id):
        args = note_put_args.parse_args()
        result = NoteModel.query.filter_by(id=note_id).first()
        if not result:
            abort(404, message="Note doesn't exist, cannot update")

        user = get_jwt_identity()
        if user not in result.editors:
            abort(403, message="You're not allowed to edit this note")

        if args['name']:
            result.name = args['name']
        if args['text']:
            if len(args['text']) > 404:
                abort(403, message="Text longer than 404 characters is not allowed")

            result.text = args['text']
        if args['editors']:
            editors = args['editors']
            owner = result.owner
            for editor in editors:
                editor_exists = UserModel.query.filter_by(id=editor).first()
                if not editor_exists:
                    abort(404, message="Could not find editor with that id")

            if len(args['editors']) > 5:
                abort(403, message="More than 5 editors is not allowed")

            if owner not in editors:
                editors.append(owner)

            result.editors = editors

        result = db.session.merge(result)
        db.session.commit()

        return result, 200

    @jwt_required
    def delete(self, note_id):
        result = NoteModel.query.filter_by(id=note_id).first()
        if not result:
            abort(404, message="Can not delete nonexistent note")

        if result.owner != get_jwt_identity():
            abort(403, message="Can not delete note of other user")

        result = db.session.merge(result)
        db.session.delete(result)
        db.session.commit()
        return 204


class User(Resource):
    @marshal_with(user_resource_fields)
    def get(self, user_id):
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="Could not find user with that id")
        return result, 200

    @marshal_with(user_resource_fields)
    def put(self, user_id):
        args = user_put_args.parse_args()
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="User doesn't exist, cannot update")

        if args['username']:
            result.username = args['username']
        if args['password']:
            result.password = generate_password_hash(args['password'])

        result = db.session.merge(result)
        db.session.commit()

        return result, 200

    def delete(self, user_id):
        result = UserModel.query.filter_by(id=user_id).first()
        if not result:
            abort(404, message="Can not delete nonexistent user")

        result = db.session.merge(result)
        db.session.delete(result)
        db.session.commit()
        return 204


class AllNotes(Resource):
    @marshal_with(note_resource_fields)
    def get(self):
        result = NoteModel.query.all()

        return result, 200


class AllUsers(Resource):
    @marshal_with(user_resource_fields)
    def get(self):
        result = UserModel.query.all()

        return result, 200


api.add_resource(Notebook, "/notebook")
api.add_resource(Users, "/users")
api.add_resource(Note, "/note/<int:note_id>")
api.add_resource(User, "/user/<int:user_id>")
api.add_resource(AllNotes, "/allnotes")
api.add_resource(AllUsers, "/allusers")

if __name__ == "__main__":
    app.run(debug=True)
