from flask_restful import fields


note_resource_fields = {
    'id': fields.Integer,
    'name': fields.String,
    'text': fields.String,
    'owner': fields.Integer,
    'editors': fields.List(fields.Integer)
}

user_resource_fields = {
    'id': fields.Integer,
    'username': fields.String,
    'password': fields.String
}
